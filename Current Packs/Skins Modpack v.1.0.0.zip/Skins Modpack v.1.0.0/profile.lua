return {
    name = "Skin Modpack",
    main_colour = "009dff",
    secondary_colour = "546385", -- Sets the colour of profile buttons.
    description = "Only Steamodded skins made by the Balatro modding community. Make sure to check credits.txt for all the authors!",
    author = {"SeSebasti"},
    url = "https://github.com/Sesebasti/BalatroDeckSkins",
    version = "v1.0.0",
}