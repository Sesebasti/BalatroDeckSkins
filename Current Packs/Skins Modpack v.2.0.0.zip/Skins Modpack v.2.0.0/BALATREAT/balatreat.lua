--- STEAMODDED HEADER
--- MOD_NAME: BALATREAT
--- MOD_ID: BALATREAT
--- PREFIX: BALATREAT
--- MOD_AUTHOR: [NomnomNami]
--- MOD_DESCRIPTION: The Gays Are Here
--- BADGE_COLOR: FF1C1C
--- VERSION: 1.0.0


SMODS.Atlas { key = "8bitdeck",
    path = "8BitDeck.png",
    px = 71,
    py = 95, }
SMODS.Atlas { key = "8bitdeckopt2",
    path = "8BitDeck_Opt2.png",
    px = 71,
    py = 95, }
    
SMODS.DeckSkin { key = "8bitdeckHearts",
    suit = "Hearts",
    loc_txt = "LWT",
    palettes = { 
        {   key = 'Low Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeck",
            pos_style = "deck" },
        {   key = 'High Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeckopt2",
            pos_style = "deck" }    },
}
SMODS.DeckSkin { key = "8bitdeckClubs",
    suit = "Clubs",
    loc_txt = "LWT",
    palettes = { 
        {   key = 'Low Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeck",
            pos_style = "deck" },
        {   key = 'High Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeckopt2",
            pos_style = "deck" }    },
}
SMODS.DeckSkin { key = "8bitdeckDiamonds",
    suit = "Diamonds",
    loc_txt = "LWT",
    palettes = { 
        {   key = 'Low Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeck",
            pos_style = "deck" },
        {   key = 'High Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeckopt2",
            pos_style = "deck" }    },
}
SMODS.DeckSkin { key = "8bitdeckSpades",
    suit = "Spades",
    loc_txt = "LWT",
    palettes = { 
        {   key = 'Low Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeck",
            pos_style = "deck" },
        {   key = 'High Contrast',
            ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" },
            display_ranks = { "King", "Queen", "Jack" },
            atlas = "BALATREAT_8bitdeckopt2",
            pos_style = "deck" }    },
}