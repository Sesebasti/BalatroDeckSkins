======
LONELY WOLF TREAT BALATRO MOD
by NomnomNami
======

AUTHOR'S NOTE:
hello!!!!! i made these card designs for personal use, but i know others would enjoy them too so i'm sharing the files :)
when i found out how easy it was to replace the art assets in the steam version i couldn't resist...
i'm including instructions but it assumes you're modding the steam version on windows (i can't help if you're on mac or something)

pwease don't redistribute/reupload these files, just link to my site instead:
> https://nomnomnami.com/games/treat/downloads/balatreat.html
this mod is not for profit! if someone sold it to you, you got scammed!!!

======

MODDING INSTRUCTIONS:
https://steamcommunity.com/sharedfiles/filedetails/?id=3207472768
(i wrote an offline version below, this link is just the guide i followed when making this)

======

INCLUDED FILES:
* 1x/8BitDeck.png - these are the playing cards! K Q and J are redrawn for all suits, the rest are untouched.
  (the game will use this file if you turn pixel smoothing OFF)
* 1x/8BitDeck_opt2.png - high contrast version
* 2x/8BitDeck.png - the same cards, just larger. the game uses this file if you have pixel smoothing turned ON.
* 2x/8BitDeck_opt2.png - high contrast version (but bigger)

======

INSTALLATION GUIDE:
* download 7-zip so you can crack open the game files 
  > https://7-zip.org/
* make sure the game is closed before you start messing with it lol

1. in your steam library, right click on Balatro, then go to Manage > Browse Local Files
2. right click Balatro.exe, then go to 7-zip > Open Archive
3. double click "resources", then "textures". there will be two folders inside, "1x" and "2x"
4. extract 8BitDeck2.png and 8BitDeck_opt2.png so you can keep a backup copy of the original art
  (otherwise you can probably just redownload balatro if you want to change it back to normal)
  (you can extract them by clicking the file, then clicking the big blue "-" button at the top where it says extract)
5. drag and drop the LWT versions into the 7-zip window to replace them.
  (you don't need to replace all four, just whatever your game is set to... i explained the files above!)
6. open Balatro, then go to Options > Customize Deck. the LWT cards will be there as the default option :)

if it doesn't show up, try changing your settings (pixel smoothing/high contrast) in case it was set to the wrong one.
otherwise it should all work... i hope it works?! it worked for me!!!

======

thanks for downloading! i might make more of these (like the tarot seems fun) but i won't promise anything.
please enjoy <3