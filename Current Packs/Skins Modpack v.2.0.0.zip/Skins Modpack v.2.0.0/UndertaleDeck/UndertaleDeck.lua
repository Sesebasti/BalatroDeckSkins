--- STEAMODDED HEADER
--- MOD_NAME: Undertale Deck
--- MOD_ID: UndertaleDeck
--- PREFIX: Undertale
--- MOD_AUTHOR: [nolo33lp]
--- MOD_DESCRIPTION: Replaces default face cards king, queen, jack, to  Undertale characters.

------------------------------------------------
------------------------------------------------

ranks = {"Jack", "Queen", "King"}

SMODS.Atlas {
	key = 'Undertaleplace',
	px = 71,
	py = 95,
	disable_mipmap = true,
	path = 'Undertaledeck.png'
    }
	
SMODS.Atlas {
	key = 'Undertaleplace_hc',
	px = 71,
	py = 95,
	disable_mipmap = true,
	path = 'Undertaledeck_hc.png'
    }
	

SMODS.DeckSkin ({
	key = 'Undertale1',
	suit = "Hearts",
	ranks = ranks,
	lc_atlas = 'Undertale_Undertaleplace',
	hc_atlas = 'Undertale_Undertaleplace_hc',
	loc_txt = {
        ['en-us'] = 'Undertale'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Undertale2',
	suit = "Clubs",
	ranks = ranks,
	lc_atlas = 'Undertale_Undertaleplace',
	hc_atlas = 'Undertale_Undertaleplace_hc',
	loc_txt = {
        ['en-us'] = 'Undertale'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Undertale3',
	suit = "Spades",
	ranks = ranks,
	lc_atlas = 'Undertale_Undertaleplace',
	hc_atlas = 'Undertale_Undertaleplace_hc',
	loc_txt = {
        ['en-us'] = 'Undertale'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Undertale4',
	suit = "Diamonds",
	ranks = ranks,
	lc_atlas = 'Undertale_Undertaleplace',
	hc_atlas = 'Undertale_Undertaleplace_hc',
	loc_txt = {
        ['en-us'] = 'Undertale'
    },
	pos_style = 'deck'
	})


------------------------------------------------
------------------------------------------------