--- STEAMODDED HEADER
--- MOD_NAME: Kobayashi_Dragons
--- MOD_ID: kob_deck
--- PREFIX: kob
--- MOD_AUTHOR: [Scruby, Mahuru, Gatler, DoubleV]
--- MOD_DESCRIPTION: Kobayashi set of face cards
--- LOADER_VERSION_GEQ: 1.0.0
--- VERSION: 1.0.0
--- BADGE_COLOR: FF3800

local atlas_key = 'kob_atlas'                                                           -- "{prefix}_atlas"

local atlas_lc_img = 'kob_lc.png'                                                       -- Filename for the image in the asset folder
local atlas_hc_img = 'kob_hc.png'                                                       -- Optional, comment out if not used
local atlas_extra_img = { 'kos_lc.png', 'kos_hc.png' }                                  -- One image per extra palette, optional, comment out if not used

local suits = { 'Clubs' }                                                               -- Which suits to replace
local ranks_to_use = { 'Jack', 'Queen', "King", "Ace" }                                 -- Which ranks to replace

local icon = true                                                                       -- Whether to register a mod icon

local description = { "Kobayashi\'s Dragons" }                                          -- English-language description, also used as default. Can also be a table for each suit.
local palette_description = { 'Rotational (Low Contrast)', 'Rotational (High Contrast)' } -- Description for each extra palette, optional, comment out if not used

-----------------------------------------------------------
-- You should only need to change things above this line --
-----------------------------------------------------------

-- Registers the mod icon
if icon then
    SMODS.Atlas { -- modicon
        key = 'modicon',
        px = 32,
        py = 32,
        path = 'modicon.png'
    }
end

-- Atlases
SMODS.Atlas {
    key = atlas_key .. '_lc',
    px = 71,
    py = 95,
    path = atlas_lc_img
}

if atlas_hc_img then
    SMODS.Atlas {
        key = atlas_key .. '_hc',
        px = 71,
        py = 95,
        path = atlas_hc_img
    }
end

if atlas_extra_img then
    for i, extra_img in ipairs(atlas_extra_img) do
        SMODS.Atlas {
            key = atlas_key .. '_extra' .. i,
            px = 71,
            py = 95,
            path = extra_img
        }
    end
end

-- DeckSkin

for i, suit in ipairs(suits) do
    local palettes = {}

    -- Low-contrast palette
    local lc_palette = {
        key = "lc",
        ranks = ranks_to_use,
        display_ranks = ranks_to_use,
        atlas = atlas_key .. '_lc',
        pos_style = "deck"
    }
    table.insert(palettes, lc_palette)

    -- High-contrast palette if provided
    if atlas_hc_img then
        local hc_palette = {
            key = "hc",
            ranks = ranks_to_use,
            display_ranks = ranks_to_use,
            atlas = atlas_key .. '_hc',
            pos_style = "deck",
            hc_default = true,
        }
        table.insert(palettes, hc_palette)
    end

    -- Extra palettes if provided
    if atlas_extra_img then
        for j, extra_img in ipairs(atlas_extra_img) do
            local extra_palette = {
                key = "extra" .. j,
                ranks = ranks_to_use,
                display_ranks = ranks_to_use,
                atlas = atlas_key .. '_extra' .. j,
                pos_style = "deck"
            }

            -- Add palette description if provided
            if palette_description and palette_description[j] then
                extra_palette.loc_txt = palette_description[j]
                if string.find(string.lower(palette_description[j]), "hc") or string.find(string.lower(palette_description[j]), "high contrast") then
                    hc_default = true
                end
            end
            table.insert(palettes, extra_palette)
        end
    end

    -- Description(s)
    local desc = description
    if type(description) == "table" then
        desc = description[i]
    end

    SMODS.DeckSkin {
        key = string.lower(suit) .. '_skin',
        suit = suit,
        loc_txt = desc,
        palettes = palettes
    }
end
