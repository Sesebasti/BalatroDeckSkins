SMODS.Atlas {
    key = "skins_isat",
    path = "SkinISAT.png",
    px = 71,
    py = 95
}

SMODS.Atlas {
    key = "skins_isat_hc",
    path = "SkinISAT_2.png",
    px = 71,
    py = 95
}

SMODS.DeckSkin {
    key = 'isat',
    suit = 'Spades',
    loc_txt = "In Stars and Time",
    palettes = {
        {
            key = 'lc',
            ranks = { 'Jack', 'Queen', 'King' },
            display_ranks = { 'King', 'Queen', 'Jack' },
            pos_style = 'ranks',
            atlas = 'ISATdeckskin_skins_isat'
        },
        {
            -- it's literally monochromatic, how the crab would I low contrast this
            -- nvmd turns out I could and I did
            key = 'hc',
            ranks = { 'Jack', 'Queen', 'King' },
            display_ranks = { 'King', 'Queen', 'Jack' },
            pos_style = 'ranks',
            atlas = 'ISATdeckskin_skins_isat_hc',
            hc_default = true
        }
    }
}
