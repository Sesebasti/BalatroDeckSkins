--- STEAMODDED HEADER
--- MOD_NAME: Hollow Knight Deck
--- MOD_ID: HollowDeck
--- PREFIX: hollow
--- MOD_AUTHOR: [nolo33lp]
--- MOD_DESCRIPTION: Replaces default face cards king, queen, jack, to hollow knight characters.

------------------------------------------------
------------------------------------------------

ranks = {"Jack", "Queen", "King"}

SMODS.Atlas {
	key = 'hollowplace',
	px = 71,
	py = 95,
	disable_mipmap = true,
	path = 'hollowdeck.png'
    }
	
SMODS.Atlas {
	key = 'hollowplace_hc',
	px = 71,
	py = 95,
	disable_mipmap = true,
	path = 'hollowdeck_hc.png'
    }
	

SMODS.DeckSkin ({
	key = 'Hollow knight1',
	suit = "Hearts",
	ranks = ranks,
	lc_atlas = 'hollow_hollowplace',
	hc_atlas = 'hollow_hollowplace_hc',
	loc_txt = {
        ['en-us'] = 'Hollow knight'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Hollow knight2',
	suit = "Clubs",
	ranks = ranks,
	lc_atlas = 'hollow_hollowplace',
	hc_atlas = 'hollow_hollowplace_hc',
	loc_txt = {
        ['en-us'] = 'Hollow knight'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Hollow knight3',
	suit = "Spades",
	ranks = ranks,
	lc_atlas = 'hollow_hollowplace',

	hc_atlas = 'hollow_hollowplace_hc',
	loc_txt = {
        ['en-us'] = 'Hollow knight'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Hollow knight4',
	suit = "Diamonds",
	ranks = ranks,
	lc_atlas = 'hollow_hollowplace',
	hc_atlas = 'hollow_hollowplace_hc',
	loc_txt = {
        ['en-us'] = 'Hollow knight'
    },
	pos_style = 'deck'
	})


------------------------------------------------
------------------------------------------------