--- STEAMODDED HEADER
--- MOD_NAME: Deltarune Deck
--- MOD_ID: DeltaruneDeck
--- PREFIX: Deltarune
--- MOD_AUTHOR: [nolo33lp]
--- MOD_DESCRIPTION: Replaces default face cards king, queen, jack, to  Deltarune characters.

------------------------------------------------
------------------------------------------------

ranks = {"Jack", "Queen", "King"}

SMODS.Atlas {
	key = 'Deltaruneplace',
	px = 71,
	py = 95,
	disable_mipmap = true,
	path = 'Deltarunedeck.png'
    }
	
SMODS.Atlas {
	key = 'Deltaruneplace_hc',
	px = 71,
	py = 95,
	disable_mipmap = true,
	path = 'Deltarunedeck_hc.png'
    }
	

SMODS.DeckSkin ({
	key = 'Deltarune1',
	suit = "Hearts",
	ranks = ranks,
	lc_atlas = 'Deltarune_Deltaruneplace',
	hc_atlas = 'Deltarune_Deltaruneplace_hc',
	loc_txt = {
        ['en-us'] = 'Deltarune'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Deltarune2',
	suit = "Clubs",
	ranks = ranks,
	lc_atlas = 'Deltarune_Deltaruneplace',
	hc_atlas = 'Deltarune_Deltaruneplace_hc',
	loc_txt = {
        ['en-us'] = 'Deltarune'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Deltarunee3',
	suit = "Spades",
	ranks = ranks,
	lc_atlas = 'Deltarune_Deltaruneplace',
	hc_atlas = 'Deltarune_Deltaruneplace_hc',
	loc_txt = {
        ['en-us'] = 'Deltarune'
    },
	pos_style = 'deck'
	})

SMODS.DeckSkin ({
	key = 'Deltarune4',
	suit = "Diamonds",
	ranks = ranks,
	lc_atlas = 'Deltarune_Deltaruneplace',
	hc_atlas = 'Deltarune_Deltaruneplace_hc',
	loc_txt = {
        ['en-us'] = 'Deltarune'
    },
	pos_style = 'deck'
	})


------------------------------------------------
------------------------------------------------