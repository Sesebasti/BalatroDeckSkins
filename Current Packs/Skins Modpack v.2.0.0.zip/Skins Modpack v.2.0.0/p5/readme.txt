Requires steammodded!
Unzip and place the 'p5' folder into your mods folder :)