return {
    name = "Skin Modpack",
    main_colour = "e18400",
    secondary_colour = "bd5837", -- Sets the colour of profile buttons.
    description = "Only Steamodded skins made by the Balatro modding community. Make sure to check credits.txt for all the authors!",
    author = {"SeSebasti"},
    url = "https://github.com/Sesebasti/BalatroDeckSkins",
    version = "v2.0.0",
}